﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="forget-pass.aspx.cs" Inherits="ecommerce_customer" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="generator" content="CoolAdmin 3.4.0"/>
  <meta name="description" content="Password recovery page with clean form layout."/>
  <title>Forgot password | CoolAdmin Bootstrap 5 Admin Dashboard</title>
  <meta name="robots" content="noindex,nofollow"/>
  <meta property="og:type" content="website"/>
  <meta property="og:title" content="Forgot password | CoolAdmin Bootstrap 5 Admin Dashboard"/>
  <meta property="og:description" content="Password recovery page with clean form layout."/>
  <meta property="og:image" content="screenshots/cooladmin-bootstrap-dashboard-2.png"/>
  <meta name="twitter:card" content="summary_large_image"/>
  <meta name="twitter:title" content="Forgot password | CoolAdmin Bootstrap 5 Admin Dashboard"/>
  <meta name="twitter:description" content="Password recovery page with clean form layout."/>
  <meta name="theme-color" content="#4272d7"/>
  <link href="css/font-face.css" rel="stylesheet" media="all"/>
  <link rel="preconnect" href="https://rsms.me/"/>
  <link rel="stylesheet" href="https://rsms.me/inter/inter.css"/>
  <link href="vendor/fontawesome-7.3.1/css/all.min.css" rel="stylesheet" media="all"/>
  <link href="vendor/bootstrap-5.3.8.min.css" rel="stylesheet" media="all"/>
  <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all"/>
  <link href="css/theme.css" rel="stylesheet" media="all"/>
  <link href="css/app.css" rel="stylesheet" media="all"/>
</head>
  <body class="app auth-page"><a class="visually-hidden-focusable skip-link" href="#auth-form">Skip to recovery form</a>


    <form id="form1" runat="server">
        <main class="login-wrap" id="auth-form">
  <div class="login-content">            <a href="index.html" class="auth-brand" aria-label="CoolAdmin home">
            <span class="logo-mark" aria-hidden="true">C</span>
            <span class="logo-text">CoolAdmin</span>
        </a>
        <h1 class="auth-title">Reset your password</h1>
        <p class="auth-subtitle">Enter your email and we'll send you a link to reset it.</p>

        <form class="login-form" action="" method="post" onsubmit="return false">
            <div class="form-group">
                <label for="email">Email address</label>
                <input id="email" class="au-input" type="email" name="email"
                    placeholder="you@example.com" autocomplete="email" required>
            </div>
            <button class="au-btn au-btn--green" type="submit">Send reset link</button>
        </form>

        <div class="register-link">
            <p>Remembered it? <a href="login.html">Back to sign in</a></p>
        </div>

  </div>
</main>


    </form>

    <script src="js/vanilla-utils.js"></script>
    <script src="vendor/bootstrap-5.3.8.bundle.min.js"></script>
    <script src="js/bootstrap5-init.js"></script>
    <script src="js/main-vanilla.js"></script>
    <script src="js/modern-plugins.js"></script>
</body>
</html>
